**** %common defines common librefs and SAS options.;
* SAS program is provided as-is with limited support.;
%macro common;
	libname source "C:\path\source_data";
	libname library "C:\path\source_data";
	libname target "C:\path\sdtm_data";
	options ls=256 nocenter;
%mend common;
