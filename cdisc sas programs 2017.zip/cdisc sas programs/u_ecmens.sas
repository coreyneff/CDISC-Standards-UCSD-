/***********************************************************************************************

* SAS program is provided as-is with limited support.

Program Name           : u_ecmens.sas 

Path                   : /stat/peggcsf/sd01/utilities/scl_user

Study Number(s)        :  

Program Type           : SAS 8.2 

Platform               : 

Operating System       : 

Program Description    : This program performs proc means for data validations. 
                         
Location of Electronic
  Validation Docs      : /stat/peggcsf/sd01/studyid/analysis/final/output/validation

Run Dependencies       :

Input                  :

Output                 :

Output Specification   : Refer to analysis plan.

Macro calls internal   : 
Macro calls external   :  

Output lists, etc.     :

Storage/Control Specs  :

Mod#    Date            Username        Description
---     -------         --------        ---------------------------------------------------
001     01feb2000         sgupta        modified/created program

**********************************************************************************************/
* Macro to use Proc means;

%macro u_ecmens(
             edsn=c990736.vlabs,   /* Harmonized dataset name */
             ecvr=_numeric_,      /* numeric variable */
             esub=,                /* optional subset condition where statement  ex. where labnme='wbc' */
             byvars=,               /* optional variables in class statement, must include keyword class */ 
		  ecopt=missing,         /* optional proc means options */
		  outdsn=,               /* optional output dataset, has to include statistics assignment */
             fnote=                /* optional footnote */
             );

 title1 "Study: &study - Edit Check in &edsn dataset"; 
 title2 "PROC MEANS of %upcase(&ecvr) variable with the condition: &esub"; 
 %if %length(&fnote)>0 %then %do;
    %if %index(&fnote,\)=0 %then footnote3 &fnote.;;
	%if %index(&fnote,\)>0 %then %do;
	  %let fnote3=%scan(&fnote,1,\);
	  footnote3 &fnote3;
	  %let fnote4=%scan(&fnote,2,\);
	  footnote4 &fnote4;
	%end;
 %end;

 proc means data=&edsn &ecopt;
  var &ecvr; 
  %if %length(&outdsn)>0 %then
    output out=&outdsn;;
  &esub;
  &byvars;
run;

 title1; footnote3;

%mend u_ecmens;
