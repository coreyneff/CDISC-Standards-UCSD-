*----------------------------------------------------------------*;
* smake_sort_order.sas creates a global macro variable called  ;
* **SORTSTRING where ** is the name of the dataset that contains;  
* the metadata specified sort order for a given dataset.;
*
* MACRO PARAMETERS:;
* metadatafile = the file containing the dataset metadata;
* dataset = the dataset or domain name;
* SAS program is provided as-is with limited support.;
*----------------------------------------------------------------*;
%macro smake_sort_order(metadatafile=stoc_metadata, dataset=);

/*
    proc import 
        datafile="&metadatafile"
        out=_temp 
        dbms=excelcs
        replace;
        sheet="TOC_METADATA";
    run;
*/

    ** create **SORTSTRING macro variable;
    %global &dataset.SORTSTRING;

    data _null_;
      set SDTM_METADATA;

        where name = "&dataset";
    
        call symputx(compress("&dataset" || "SORTSTRING"), 
                     translate(domainkeys," ",","));
    run;
     
%mend smake_sort_order;
