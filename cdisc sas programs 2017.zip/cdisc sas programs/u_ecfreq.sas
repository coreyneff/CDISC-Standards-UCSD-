/***********************************************************************************************

* SAS program is provided as-is with limited support.

Program Name           : u_ecfreq.sas 

Path                   : /stat/peggcsf/sd01/utilities/scl_user

Study Number(s)        :  

Program Type           : SAS 8.2 

Platform               : 

Operating System       : 

Program Description    : This program performs edit checks using Proc freq. 
                         
Location of Electronic
  Validation Docs      : /stat/peggcsf/sd01/studyid/analysis/final/output/validation

Run Dependencies       :

Input                  :

Output                 : 

Output Specification   : Refer to analysis plan.

Macro calls internal   : 
Macro calls external   :  

Output lists, etc.     : 

Storage/Control Specs  :

Mod#    Date            Username        Description
---     -------         --------        ---------------------------------------------------
001     01feb2000       sgupta          modified/created program
    

**********************************************************************************************/
* Macro to use Proc freq;

%macro u_ecfreq(
             edsn=c990736.vlabs,  /* Harmonized dataset name */
             ecvr=_all_,         /* variable or list of variables also can pass cross tables with options */
             esub=,               /* subset condition where statement, can also be a format statement*/
             fnote=               /* optional footnote */
             );

 title1 "Study: &study - Edit Check in &edsn dataset"; 
 title2 "PROC FREQ of %upcase(&ecvr) variable with the condition: &esub"; 
 
 %if %length(&fnote)>0 %then %do;
    %if %index(&fnote,\)=0 %then footnote3 &fnote.;;
	%if %index(&fnote,\)>0 %then %do;
	  %let fnote3=%scan(&fnote,1,\);
	  footnote3 &fnote3;
	  %let fnote4=%scan(&fnote,2,\);
	  footnote4 &fnote4;
	%end;
 %end;

 proc freq data=&edsn;
  tables &ecvr; 
  &esub;
 run;

footnote3;

%mend u_ecfreq;

