*---------------------------------------------------------------*;
* ADAE.sas creates the ADaM ADAE-structured data set;
* for AE data (ADAE), saved to the ADaM libref.;
* SAS program is provided as-is with limited support.;
*---------------------------------------------------------------*;

%*include "setup.sas";


**** CREATE EMPTY ADAE DATASET CALLED EMPTY_ADAE;
options mprint ;*symbolgen;
%let metadatafile=&path/data/adam-metadata/ADAM_METADATA.xlsx;
%amake_empty_dataset(metadatafile=&metadatafile,dataset=ADAE);


proc sort
  data = adsl
  (keep = usubjid siteid country age agegr1 agegr1n sex race trtsdt trt01a trt01an saffl)
  out = adsl;
    by usubjid;
    
data adae;
  merge ae (in = inae) adsl (in = inadsl);
    by usubjid ;
    
        if inae and not inadsl then
          put 'PROB' 'LEM: Subject missing from ADSL?-- ' usubjid= inae= inadsl= ;
        
        rename trt01a    = trta
               trt01an   = trtan
        ;               
        if inadsl and inae;
        
        %dtc2dt(aestdtc, prefix=aes, refdt=trtsdt);
        %dtc2dt(aeendtc, prefix=aee, refdt=trtsdt);

        if index(AEDECOD, 'PAIN')>0 or AEDECOD='HEADACHE' then
          CQ01NAM = 'PAIN EVENT';
        else
          CQ01NAM = '          ';
          
        aereln = input(put(aerel, $naerel_adverse_aerel.), best.);
       * aesevn = input(put(aesev, $aesevn.), best.);
        relgr1n = (aereln); ** group related events (AERELN > 0);
       * relgr1  = put(relgr1n, relgr1n.);

        if aesdt >= trtsdt then
          trtemfl = 'Y';
        format aesdt aeedt yymmdd10.;
run;

** assign variable order and labels;
data adae;
  retain &adaeKEEPSTRING;
  set EMPTY_adae adae;
run;

**** SORT adae ACCORDING TO METADATA AND SAVE PERMANENT DATASET;
%amake_sort_order(metadatafile=&metadatafile, dataset=ADAE);

proc sort
  data=adae(keep = &adaeKEEPSTRING)
  out=adae;
    by &adaeSORTSTRING;
run;        

