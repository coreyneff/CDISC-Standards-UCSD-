*------------------------------------------------------------*;
* ADSL.sas creates the ADaM ADSL data set;
* as permanent SAS datasets to the ADaM libref.;
* SAS program is provided as-is with limited support.;
*------------------------------------------------------------*;

%*include "..\setup.sas";

proc format;
 value _0n1y 0 = 'N'
             1 = 'Y'
             other = '.'; 
run;

**** CREATE EMPTY ADSL DATASET CALLED EMPTY_ADSL;

%let metadatafile=&path/data/adam-metadata/adam_metadata.xlsx;
%amake_empty_dataset(metadatafile=&metadatafile, dataset=ADSL); 

** merge supplemental qualifiers into DM;
%mergsupp(sourcelib=sdtm, domains=DM); 

** find the change from baseline so that responders can be flagged ;
** (2-point improvement in pain at 6 months);
%cfb(indata=xp, outdata=responders, dayvar=xpdy, avalvar= xpstresn, 
     keepvars=usubjid visitnum chg);

data ADSL;
    merge EMPTY_ADSL
          	DM         (in = inDM) 
          	responders (in = inresp where=(visitnum=2))
          	;
      by usubjid;

        * convert RFSTDTC to a numeric SAS date named TRTSDT;
        %dtc2dt(RFSTDTC, prefix=TRTS );  

        * create BRTHDT, RANDDT, TRTEDT;
        %dtc2dt(BRTHDTC, prefix=BRTH);        
        %dtc2dt(RANDDTC, prefix=RAND);
        %dtc2dt(RFENDTC, prefix=TRTE);

        * created flags for ITT and safety-evaluable;
        *ittfl = put(randdt, popfl.);
        *saffl = put(trtsdt, popfl.);
        if randdt > . then ittfl='Y'; else ittfl='N';
        if trtsdt > . then saffl='Y'; else saffl='N';

        trt01p = ARM;
        trt01a = trt01p;
	trt01pn = 1;
	trt01an = 1;
        agegr1n=age;
	agegr1=age;
	respfl= chg;

  *      trt01pn = input(put(trt01p, $trt01pn.), best.);
  *      trt01an = trt01pn;                 
  *      agegr1n = input(put(age, agegr1n.), best.);
  *      agegr1  = put(agegr1n, agegr1_.);
        RESPFL = put((.z <= chg <= -2), _0n1y.);         
run;

**** SORT ADSL ACCORDING TO METADATA AND SAVE PERMANENT DATASET;  
%amake_sort_order(metadatafile=&metadatafile, dataset=ADSL); 

proc sort
  data=adsl
  (keep = &ADSLKEEPSTRING)
  out=adsl;
    by &ADSLSORTSTRING;
run;
