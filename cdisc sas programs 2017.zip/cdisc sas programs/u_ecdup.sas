/**********************************************************************************

* SAS program is provided as-is with limited support.

Program Name           : u_ecdup.sas 

Path                   : /stat/final/statfiles/editchecks/macros 


Study Number(s)        :  

Program Type           : SAS 8.2 

Platform               : 

Operating System       : 

Program Description    : This program performs edit checks for duplicated records by key variables or by all variables
                         
Location of Electronic
  Validation Docs      : 

Run Dependencies       :

Input                  :

Output                 : 

Output Specification   : Refer to analysis plan.

Macro calls internal   : 
Macro calls external   :  

Output lists, etc.     : 

Storage/Control Specs  :

Mod#    Date            Username        Description
---     -------         --------        -------------------------------------------
001     10nov99         sgupta          created program, modified/adapted from

**********************************************************************************/


%macro u_ecdup(
               edsn=,       /* Data set name */
               ecvr=_all_,  /* Error check variables,default is all variables */ 
               ecvrl=,      /* Extra variables to be kept in the output dataset */
               fnote=,      /* Optional footnote */
               eoutdsn=     /* Output dataset */
               );

proc sort data=&edsn out=two;
    by &ecvr;
run;

*&c1 is the last variable;

%if &ecvr=_all_ %then %do;

  proc contents data=&edsn out=_tmpout noprint;
  run;

  proc sql noprint;
   select name into: c1
   from _tmpout
   where VARNUM=(select max(VARNUM) 
               from _tmpout)
  ;
  quit;
%end;

%else %do;
 %let c1=%scan(&ecvr,-1);
%end;

*keep one record for duplicated ones;

data _eoutdsn(keep=&ecvr) &eoutdsn.;
 set two;
 by &ecvr;
 keep &ecvr &ecvrl;
 if not(first.&c1 and last.&c1);
 %if %length(&eoutdsn)>0 %then output &eoutdsn.;;
 if first.&c1 then output _eoutdsn;
run;

data _ecdup;
 label errcode = 'Error Code';
  if ncount =  0 then do;
     errcode= "No duplicated records found for %upcase(&ecvr)";
     output;
     stop;
  end;
  else do;
     errcode= " ";
     output;
     stop;
  end;
 set _eoutdsn nobs=ncount;
run;

title1 "Study: &study - Edit Check in &edsn dataset";
title2 "Indicate the result of checking for duplicated records"; 
 
 %if %length(&fnote)>0 %then %do;
    %if %index(&fnote,\)=0 %then footnote3 &fnote.;;
	%if %index(&fnote,\)>0 %then %do;
	  %let fnote3=%scan(&fnote,1,\);
	  footnote3 &fnote3;
	  %let fnote4=%scan(&fnote,2,\);
	  footnote4 &fnote4;
	%end;
 %end;

proc print data=_ecdup noobs label;
  var errcode;
  where errcode > " ";
run;

*print out the duplicated records only when eoutdsn is not specified;
%if %length(&eoutdsn)=0 %then %do;
  proc print data=_eoutdsn noobs label;
    title3 "Duplicated Records are shown below";
  run;
%end;

footnote3;

%mend u_ecdup;




















